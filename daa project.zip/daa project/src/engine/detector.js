import { SUSPICIOUS_PHRASES } from './dataset.js';
import { AhoCorasick } from './ahoCorasick.js';

// Initialize and build Aho-Corasick automaton once
const automaton = new AhoCorasick();

for (const item of SUSPICIOUS_PHRASES) {
  automaton.insert(item.phrase, item.category, item.weight);
}

automaton.buildFailureLinks();

/**
 * Pure Trie & Aho-Corasick Detection Engine.
 * Detects suspicious language patterns, clickbait, scam, misinformation, and fake news triggers.
 *
 * Verdict Rules:
 * - 0 patterns found = "No Suspicious Patterns"
 * - 1 - 29 = "Low Suspicion"
 * - 30 - 59 = "Needs Review"
 * - 60 - 100 = "Likely Fake"
 */
export function analyzeText(text) {
  if (!text || !text.trim()) {
    return {
      suspicionScore: 0,
      verdict: 'No Suspicious Patterns',
      categoryCounts: {},
      detectedPhrases: [],
    };
  }

  // Execute Aho-Corasick pattern search
  const rawMatches = automaton.search(text);

  const categoryCounts = {};
  const phraseMap = new Map();
  let totalWeight = 0;

  for (const match of rawMatches) {
    categoryCounts[match.category] = (categoryCounts[match.category] || 0) + 1;

    const key = match.phrase.toLowerCase();
    if (!phraseMap.has(key)) {
      phraseMap.set(key, {
        phrase: match.phrase,
        category: match.category,
        context: match.context,
        weight: match.weight,
      });
      totalWeight += match.weight;
    }
  }

  const detectedPhrases = Array.from(phraseMap.values());
  const suspicionScore = Math.min(100, Math.max(0, Math.round(totalWeight)));

  // Verdict Logic based solely on Aho-Corasick pattern match severity
  let verdict = 'No Suspicious Patterns';

  if (detectedPhrases.length === 0 || suspicionScore === 0) {
    verdict = 'No Suspicious Patterns';
  } else if (suspicionScore >= 60) {
    verdict = 'Likely Fake';
  } else if (suspicionScore >= 30) {
    verdict = 'Needs Review';
  } else {
    verdict = 'Low Suspicion';
  }

  return {
    suspicionScore,
    verdict,
    categoryCounts,
    detectedPhrases,
  };
}
