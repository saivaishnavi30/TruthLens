/**
 * Comprehensive Dataset of suspicious phrases mapped to 4 categories:
 * - Clickbait
 * - Scam
 * - Misinformation
 * - Fake News
 *
 * Includes short phrases and realistic sentence patterns while excluding normal news language.
 */

export const SUSPICIOUS_PHRASES = [
  // ==================== CLICKBAIT ====================
  { phrase: "shocking", category: "Clickbait", weight: 15 },
  { phrase: "shocking secret revealed", category: "Clickbait", weight: 20 },
  { phrase: "doctors hate this", category: "Clickbait", weight: 20 },
  { phrase: "one weird trick", category: "Clickbait", weight: 20 },
  { phrase: "you won't believe", category: "Clickbait", weight: 15 },
  { phrase: "what happens next", category: "Clickbait", weight: 12 },
  { phrase: "mind blowing breakthrough", category: "Clickbait", weight: 15 },
  { phrase: "secret trick", category: "Clickbait", weight: 15 },
  { phrase: "jaw dropping", category: "Clickbait", weight: 12 },
  { phrase: "unbelievable secret", category: "Clickbait", weight: 15 },
  { phrase: "blow your mind", category: "Clickbait", weight: 12 },
  { phrase: "never seen before", category: "Clickbait", weight: 10 },
  { phrase: "guaranteed miracle", category: "Clickbait", weight: 18 },
  { phrase: "will leave you speechless", category: "Clickbait", weight: 15 },
  { phrase: "reason why will shock you", category: "Clickbait", weight: 18 },
  { phrase: "number 4 will blow your mind", category: "Clickbait", weight: 18 },
  { phrase: "what they don't want you to see", category: "Clickbait", weight: 18 },
  { phrase: "hidden secret revealed", category: "Clickbait", weight: 15 },
  { phrase: "insane secret", category: "Clickbait", weight: 14 },
  { phrase: "shocks the entire world", category: "Clickbait", weight: 16 },
  { phrase: "everyone is talking about", category: "Clickbait", weight: 10 },
  { phrase: "viral secret", category: "Clickbait", weight: 12 },

  // ==================== SCAM ====================
  { phrase: "click here to claim", category: "Scam", weight: 20 },
  { phrase: "claim your reward", category: "Scam", weight: 20 },
  { phrase: "claim your free", category: "Scam", weight: 18 },
  { phrase: "get rich quick", category: "Scam", weight: 20 },
  { phrase: "guaranteed returns", category: "Scam", weight: 18 },
  { phrase: "risk free investment", category: "Scam", weight: 18 },
  { phrase: "act now before it's taken down", category: "Scam", weight: 18 },
  { phrase: "act now before this secret", category: "Scam", weight: 18 },
  { phrase: "100% free money", category: "Scam", weight: 20 },
  { phrase: "congratulations you won", category: "Scam", weight: 20 },
  { phrase: "instant profit", category: "Scam", weight: 18 },
  { phrase: "wire transfer", category: "Scam", weight: 15 },
  { phrase: "double your money", category: "Scam", weight: 20 },
  { phrase: "no risk guaranteed", category: "Scam", weight: 18 },
  { phrase: "limited time gift", category: "Scam", weight: 14 },
  { phrase: "claim your cash", category: "Scam", weight: 18 },
  { phrase: "passive income secret", category: "Scam", weight: 16 },
  { phrase: "zero risk high return", category: "Scam", weight: 18 },
  { phrase: "free trial claim now", category: "Scam", weight: 15 },
  { phrase: "exclusive payout", category: "Scam", weight: 16 },

  // ==================== MISINFORMATION ====================
  { phrase: "cures everything", category: "Misinformation", weight: 22 },
  { phrase: "unconfirmed sources", category: "Misinformation", weight: 15 },
  { phrase: "scientists don't want you to know", category: "Misinformation", weight: 20 },
  { phrase: "hidden truth", category: "Misinformation", weight: 15 },
  { phrase: "they are hiding the cure", category: "Misinformation", weight: 22 },
  { phrase: "banned by media", category: "Misinformation", weight: 18 },
  { phrase: "secret government cover up", category: "Misinformation", weight: 20 },
  { phrase: "suppressed research", category: "Misinformation", weight: 18 },
  { phrase: "without scientific proof", category: "Misinformation", weight: 18 },
  { phrase: "conspiracy revealed", category: "Misinformation", weight: 18 },
  { phrase: "mainstream media won't tell you", category: "Misinformation", weight: 20 },
  { phrase: "the real truth behind", category: "Misinformation", weight: 14 },
  { phrase: "whistleblower leaks document", category: "Misinformation", weight: 18 },
  { phrase: "secret elite agenda", category: "Misinformation", weight: 18 },
  { phrase: "leaked memo proves", category: "Misinformation", weight: 16 },
  { phrase: "pharmaceutical companies are hiding", category: "Misinformation", weight: 20 },
  { phrase: "suppressed medical evidence", category: "Misinformation", weight: 20 },
  { phrase: "big pharma secret", category: "Misinformation", weight: 18 },
  { phrase: "deep state conspiracy", category: "Misinformation", weight: 20 },

  // ==================== FAKE NEWS ====================
  { phrase: "breaking news full blackout", category: "Fake News", weight: 20 },
  { phrase: "unprecedented miracle cure", category: "Fake News", weight: 22 },
  { phrase: "miracle cure cures everything", category: "Fake News", weight: 25 },
  { phrase: "secret formula instantly reverses", category: "Fake News", weight: 22 },
  { phrase: "banned by mainstream media", category: "Fake News", weight: 20 },
  { phrase: "whistleblower exposes truth", category: "Fake News", weight: 18 },
  { phrase: "total global collapse", category: "Fake News", weight: 20 },
  { phrase: "earth shattering news", category: "Fake News", weight: 15 },
  { phrase: "false flag operation", category: "Fake News", weight: 20 },
  { phrase: "fake emergency announced", category: "Fake News", weight: 18 },
  { phrase: "clandestine military takeover", category: "Fake News", weight: 22 },
  { phrase: "secret martial law declared", category: "Fake News", weight: 22 },
  { phrase: "unverified breaking report", category: "Fake News", weight: 15 },
  { phrase: "emergency warning to all citizens", category: "Fake News", weight: 18 },
  { phrase: "worldwide blackout imminent", category: "Fake News", weight: 22 },
  { phrase: "doomsday event confirmed", category: "Fake News", weight: 22 },
];
