/**
 * TrieNode data structure for Aho-Corasick automaton.
 */
class TrieNode {
  constructor() {
    this.children = new Map();
    this.fail = null;
    this.output = []; // Contains matching pattern metadata objects
  }
}

/**
 * Aho-Corasick Multi-Pattern String Matching Automaton.
 */
export class AhoCorasick {
  constructor() {
    this.root = new TrieNode();
  }

  /**
   * Insert a keyword/phrase pattern into the Trie.
   */
  insert(phrase, category, weight) {
    let node = this.root;
    const lowerPhrase = phrase.toLowerCase();

    for (let i = 0; i < lowerPhrase.length; i++) {
      const char = lowerPhrase[i];
      if (!node.children.has(char)) {
        node.children.set(char, new TrieNode());
      }
      node = node.children.get(char);
    }

    node.output.push({ phrase, category, weight });
  }

  /**
   * Build failure links using Breadth-First Search (BFS).
   */
  buildFailureLinks() {
    const queue = [];

    // Root children failure links point to root
    for (const [char, childNode] of this.root.children.entries()) {
      childNode.fail = this.root;
      queue.push(childNode);
    }

    // BFS for deeper nodes
    while (queue.length > 0) {
      const currentNode = queue.shift();

      for (const [char, childNode] of currentNode.children.entries()) {
        let failNode = currentNode.fail;

        while (failNode !== null && !failNode.children.has(char)) {
          failNode = failNode.fail;
        }

        if (failNode === null) {
          childNode.fail = this.root;
        } else {
          childNode.fail = failNode.children.get(char);
          // Merge output patterns from failure node
          childNode.output = childNode.output.concat(childNode.fail.output);
        }

        queue.push(childNode);
      }
    }
  }

  /**
   * Search text for all occurrences of Trie patterns in O(N + M) time.
   */
  search(text) {
    const matches = [];
    if (!text) return matches;

    const lowerText = text.toLowerCase();
    let currentNode = this.root;

    for (let i = 0; i < lowerText.length; i++) {
      const char = lowerText[i];

      while (currentNode !== null && !currentNode.children.has(char)) {
        currentNode = currentNode.fail;
      }

      if (currentNode === null) {
        currentNode = this.root;
        continue;
      }

      currentNode = currentNode.children.get(char);

      // Collect matches at current node
      if (currentNode.output.length > 0) {
        for (const pattern of currentNode.output) {
          const startIndex = i - pattern.phrase.length + 1;
          const endIndex = i + 1;

          // Extract surrounding context snippet (up to 20 chars around phrase)
          const contextStart = Math.max(0, startIndex - 15);
          const contextEnd = Math.min(text.length, endIndex + 15);
          const rawSnippet = text.substring(contextStart, contextEnd).trim();

          matches.push({
            phrase: pattern.phrase,
            category: pattern.category,
            weight: pattern.weight,
            startIndex,
            endIndex,
            context: rawSnippet,
          });
        }
      }
    }

    return matches;
  }
}
