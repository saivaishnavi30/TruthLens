import React from 'react';

export default function Hero() {
  return (
    <section className="pt-8 pb-4 text-center max-w-3xl mx-auto px-4">
      <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white mb-3">
        Detect <span className="gradient-text">Suspicious News Patterns</span>
      </h1>
      <p className="text-sm sm:text-base text-slate-400 font-normal leading-relaxed">
        Analyze news articles and statements to identify misleading phrases, clickbait, and sensationalism using Trie-based multi-pattern matching algorithms.
      </p>
    </section>
  );
}
