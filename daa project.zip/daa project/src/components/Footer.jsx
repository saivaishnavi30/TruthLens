import React from 'react';
import { ShieldCheck } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-slate-800/80 bg-[#060911] text-slate-500 py-6">
      <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between text-xs gap-3">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-indigo-400" />
          <span className="font-semibold text-slate-300">TruthLens</span>
          <span>— DAA College Project (String Matching Algorithms)</span>
        </div>

        <div>
          React + Vite + Trie / Aho-Corasick Model
        </div>
      </div>
    </footer>
  );
}
