import React from 'react';
import { Network, Zap, Calculator } from 'lucide-react';

export default function HowItWorks() {
  return (
    <section className="max-w-4xl mx-auto px-4 pb-12">
      <div className="glass-card rounded-xl p-6 border border-slate-800">
        
        <div className="mb-5 pb-3 border-b border-slate-800">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center space-x-2">
            <Zap className="w-4 h-4 text-indigo-400" />
            <span>How It Works</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Algorithmic pipeline using Trie and Aho-Corasick string matching data structures.
          </p>
        </div>

        {/* Workflow Steps: Trie -> Aho-Corasick -> Score */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 relative">
          
          {/* Step 1: Trie */}
          <div className="p-4 rounded-lg bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">
                  STEP 1
                </span>
                <Network className="w-4 h-4 text-indigo-400" />
              </div>
              <h4 className="text-sm font-bold text-white mb-1">Trie Construction</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Build a prefix tree (Trie) from a dictionary of known suspicious keywords, clickbait triggers, and sensational phrases.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800 text-[10px] font-mono text-slate-500">
              O(∑ |Pattern|) Build Time
            </div>
          </div>

          {/* Step 2: Aho-Corasick */}
          <div className="p-4 rounded-lg bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold">
                  STEP 2
                </span>
                <Zap className="w-4 h-4 text-purple-400" />
              </div>
              <h4 className="text-sm font-bold text-white mb-1">Aho-Corasick Search</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Construct failure links across Trie nodes to match all keywords simultaneously in a single linear scan of the article.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800 text-[10px] font-mono text-slate-500">
              O(N + Matches) Linear Search
            </div>
          </div>

          {/* Step 3: Score */}
          <div className="p-4 rounded-lg bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                  STEP 3
                </span>
                <Calculator className="w-4 h-4 text-emerald-400" />
              </div>
              <h4 className="text-sm font-bold text-white mb-1">Suspicion Score</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Weight matched phrases by category severity (Clickbait, Sensationalism, Unverified Claims) to compute final score & verdict.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-slate-800 text-[10px] font-mono text-slate-500">
              Score Range: 0 - 100
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
