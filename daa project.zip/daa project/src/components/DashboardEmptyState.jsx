import React from 'react';
import {
  BarChart3,
  ShieldAlert,
  Brain,
  Search,
  FileCheck2,
  AlertTriangle,
  Zap,
  CheckCircle2,
  Info,
  HelpCircle
} from 'lucide-react';

export default function DashboardEmptyState({ isAnalyzing }) {
  return (
    <section id="dashboard" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
      
      {/* Dashboard Section Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-6 border-b border-slate-800/80 gap-3">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <BarChart3 className="w-5 h-5 text-indigo-400" />
            <span>Explainable Detection Dashboard</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Detailed breakdown of credibility scores, linguistic patterns, and evidence highlights.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-medium bg-slate-900 border border-slate-800 text-slate-400">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-500" />
            <span>Status: {isAnalyzing ? 'Processing...' : 'Awaiting Input'}</span>
          </span>
        </div>
      </div>

      {/* Main Empty State Banner if not analyzing */}
      {!isAnalyzing && (
        <div className="mb-8 p-6 rounded-2xl glass-card border border-indigo-500/20 bg-gradient-to-r from-indigo-950/20 via-slate-900/60 to-purple-950/20 text-center relative overflow-hidden">
          <div className="max-w-xl mx-auto flex flex-col items-center">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center mb-3 text-indigo-400 shadow-inner">
              <Search className="w-6 h-6 animate-pulse" />
            </div>
            <h3 className="text-base font-semibold text-white mb-1">
              Ready for News Analysis
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Enter any article text or headline above and click <strong className="text-indigo-300">"Analyze News"</strong> to generate real-time credibility metrics and explainable risk scores.
            </p>
          </div>
        </div>
      )}

      {/* Dashboard Grid - Empty Cards Layout */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Card 1: Credibility Score Placeholder */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800/80 flex flex-col justify-between relative overflow-hidden group hover:border-slate-700/80 transition-colors">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center space-x-1.5">
                <ShieldAlert className="w-4 h-4 text-indigo-400" />
                <span>Credibility Score</span>
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                RANGE 0-100
              </span>
            </div>

            {/* Score Display Placeholder */}
            <div className="flex flex-col items-center justify-center py-6">
              <div className="relative w-28 h-28 flex items-center justify-center rounded-full border-4 border-dashed border-slate-800">
                <span className="text-3xl font-extrabold text-slate-600 font-mono">--</span>
              </div>
              <span className="mt-3 text-xs font-medium text-slate-500">
                Score Pending Submission
              </span>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/60 text-[11px] text-slate-500 flex justify-between items-center">
            <span>Algorithm Confidence</span>
            <span className="font-mono text-slate-600">N/A</span>
          </div>
        </div>

        {/* Card 2: Linguistic Tone & Emotion */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800/80 flex flex-col justify-between group hover:border-slate-700/80 transition-colors">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center space-x-1.5">
                <Brain className="w-4 h-4 text-purple-400" />
                <span>Linguistic Analysis</span>
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">NLP</span>
            </div>

            <div className="space-y-4 py-2">
              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Sensationalism Index</span>
                  <span className="font-mono text-slate-600">--%</span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                  <div className="bg-slate-700 h-2 rounded-full w-0" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Emotional Manipulation</span>
                  <span className="font-mono text-slate-600">--%</span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                  <div className="bg-slate-700 h-2 rounded-full w-0" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Unverified Claims Ratio</span>
                  <span className="font-mono text-slate-600">--%</span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                  <div className="bg-slate-700 h-2 rounded-full w-0" />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/60 text-[11px] text-slate-500">
            Awaiting sentiment & vocabulary analysis
          </div>
        </div>

        {/* Card 3: Source Trust & Attribution */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800/80 flex flex-col justify-between group hover:border-slate-700/80 transition-colors">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center space-x-1.5">
                <FileCheck2 className="w-4 h-4 text-blue-400" />
                <span>Source Attribution</span>
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">METRICS</span>
            </div>

            <div className="space-y-3 py-2">
              <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400">Named Sources Count</span>
                <span className="font-mono text-slate-500 font-bold">0</span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400">Anonymous Citations</span>
                <span className="font-mono text-slate-500 font-bold">0</span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400">Quote Verifiability</span>
                <span className="text-slate-500">Pending</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/60 text-[11px] text-slate-500">
            Source verification standby
          </div>
        </div>

      </div>

      {/* Full-width Section: Suspicious Pattern Highlights Placeholder */}
      <div className="mt-6 glass-card rounded-2xl p-6 border border-slate-800/80">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800/80">
          <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Explainable Suspicious Claim Highlights</span>
          </h3>
          <span className="text-xs text-slate-500">0 Flags Detected</span>
        </div>

        <div className="py-8 text-center border-2 border-dashed border-slate-800/90 rounded-xl bg-slate-950/30">
          <HelpCircle className="w-8 h-8 text-slate-700 mx-auto mb-2" />
          <p className="text-xs font-medium text-slate-400">
            No text analyzed yet
          </p>
          <p className="text-[11px] text-slate-600 max-w-md mx-auto mt-1">
            When you submit a news article, specific sentence highlights, suspicious phrasing, and logical fallacies will be pinpointed here with explainable context.
          </p>
        </div>
      </div>

      {/* Process Pipeline Footer Visual */}
      <div className="mt-6 p-4 rounded-xl bg-slate-900/40 border border-slate-800/60 flex flex-col md:flex-row md:items-center justify-between text-xs text-slate-400 gap-4">
        <div className="flex items-center space-x-2">
          <Zap className="w-4 h-4 text-indigo-400" />
          <span className="font-medium text-slate-300">TruthLens Pipeline:</span>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-[11px]">
          <span className="px-2.5 py-1 rounded bg-slate-800/80 text-slate-300">1. Text Ingestion</span>
          <span className="text-slate-600">→</span>
          <span className="px-2.5 py-1 rounded bg-slate-800/80 text-slate-300">2. Semantic Vectorizing</span>
          <span className="text-slate-600">→</span>
          <span className="px-2.5 py-1 rounded bg-slate-800/80 text-slate-300">3. Pattern Classification</span>
          <span className="text-slate-600">→</span>
          <span className="px-2.5 py-1 rounded bg-slate-800/80 text-slate-300 font-semibold text-indigo-400">4. Explainable Score Output</span>
        </div>
      </div>

    </section>
  );
}
