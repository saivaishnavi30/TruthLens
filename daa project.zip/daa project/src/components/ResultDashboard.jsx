import React from 'react';
import { ShieldAlert, AlertTriangle, CheckCircle2, Tag, Layers, Info } from 'lucide-react';

export default function ResultDashboard({ results, hasAnalyzed }) {
  if (!hasAnalyzed) {
    return null;
  }

  const {
    suspicionScore = 0,
    verdict = 'No Suspicious Patterns',
    categoryCounts = {},
    detectedPhrases = []
  } = results || {};

  // Visual styling based on verdict & score scale:
  // - Likely Fake: Rose/Red
  // - Needs Review: Amber
  // - Low Suspicion: Indigo/Blue
  // - No Suspicious Patterns: Emerald/Green
  const getVerdictStyle = () => {
    if (verdict === 'Likely Fake' || suspicionScore >= 60) {
      return {
        bg: 'bg-rose-500/10 border-rose-500/30 text-rose-400',
        icon: <ShieldAlert className="w-5 h-5 text-rose-400" />,
      };
    }
    if (verdict === 'Needs Review' || suspicionScore >= 30) {
      return {
        bg: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
        icon: <AlertTriangle className="w-5 h-5 text-amber-400" />,
      };
    }
    if (verdict === 'Low Suspicion') {
      return {
        bg: 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400',
        icon: <Info className="w-5 h-5 text-indigo-400" />,
      };
    }
    return {
      bg: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400',
      icon: <CheckCircle2 className="w-5 h-5 text-emerald-400" />,
    };
  };

  const verdictStyle = getVerdictStyle();

  return (
    <div className="max-w-4xl mx-auto px-4 mb-10 space-y-6">
      
      {/* Top Results Header Cards (Score & Verdict) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        
        {/* Suspicion Score */}
        <div className="glass-card rounded-xl p-5 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Suspicion Score
            </span>
            <p className="text-xs text-slate-500 mt-0.5">Pattern match severity metric</p>
          </div>
          <div className="flex items-baseline space-x-1">
            <span className={`text-4xl font-extrabold font-mono ${
              suspicionScore >= 60 ? 'text-rose-400' : suspicionScore >= 30 ? 'text-amber-400' : suspicionScore > 0 ? 'text-indigo-400' : 'text-emerald-400'
            }`}>
              {suspicionScore}
            </span>
            <span className="text-sm font-mono text-slate-500">/ 100</span>
          </div>
        </div>

        {/* Verdict */}
        <div className={`rounded-xl p-5 border flex items-center justify-between ${verdictStyle.bg}`}>
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Verdict
            </span>
            <h3 className="text-lg font-bold mt-0.5">{verdict}</h3>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-950/40">
            {verdictStyle.icon}
          </div>
        </div>

      </div>

      {/* Category Counts */}
      <div className="glass-card rounded-xl p-5 border border-slate-800">
        <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center space-x-2">
          <Layers className="w-4 h-4 text-indigo-400" />
          <span>Category Counts</span>
        </h4>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {Object.keys(categoryCounts).length > 0 ? (
            Object.entries(categoryCounts).map(([catName, count]) => (
              <div key={catName} className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 text-center">
                <span className="text-xs text-slate-400 block truncate">{catName}</span>
                <span className="text-xl font-bold text-indigo-400 font-mono mt-1 block">{count}</span>
              </div>
            ))
          ) : (
            <div className="col-span-full text-xs text-slate-500 text-center py-2">
              No categories flagged
            </div>
          )}
        </div>
      </div>

      {/* Detected Suspicious Phrases with Category */}
      <div className="glass-card rounded-xl p-5 border border-slate-800">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
          <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center space-x-2">
            <Tag className="w-4 h-4 text-purple-400" />
            <span>Detected Suspicious Phrases</span>
          </h4>
          <span className="text-xs text-slate-500 font-mono">
            Total: {detectedPhrases.length}
          </span>
        </div>

        {detectedPhrases.length > 0 ? (
          <div className="divide-y divide-slate-800/80">
            {detectedPhrases.map((item, idx) => (
              <div key={idx} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="space-y-0.5">
                  <span className="text-sm font-semibold text-slate-200">
                    "{item.phrase}"
                  </span>
                  {item.context && (
                    <p className="text-xs text-slate-400 italic">
                      "...{item.context}..."
                    </p>
                  )}
                </div>

                <span className="inline-flex items-center text-xs font-medium px-2.5 py-1 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 shrink-0 self-start sm:self-center">
                  {item.category}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-6 text-center text-xs text-slate-500">
            No suspicious phrases detected in this article.
          </div>
        )}
      </div>

    </div>
  );
}
