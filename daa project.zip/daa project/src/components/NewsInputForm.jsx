import React from 'react';
import { Sparkles, FileText, BookOpen, Trash2 } from 'lucide-react';

export default function NewsInputForm({
  newsText,
  setNewsText,
  onAnalyze,
  isAnalyzing,
  onLoadSample
}) {
  const wordCount = newsText.trim() ? newsText.trim().split(/\s+/).length : 0;
  const charCount = newsText.length;

  return (
    <div className="max-w-4xl mx-auto px-4 my-6">
      <div className="glass-panel rounded-xl p-4 sm:p-5 border border-slate-800 shadow-xl bg-slate-900/70">
        
        {/* Form Top Toolbar */}
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800 text-xs">
          <div className="flex items-center space-x-2 text-slate-300 font-semibold">
            <FileText className="w-4 h-4 text-indigo-400" />
            <span>News Article Text</span>
          </div>

          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={onLoadSample}
              className="inline-flex items-center space-x-1.5 text-indigo-400 hover:text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 px-2.5 py-1 rounded transition-colors font-medium border border-indigo-500/20"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Load Sample News</span>
            </button>

            {newsText && (
              <button
                type="button"
                onClick={() => setNewsText('')}
                className="inline-flex items-center space-x-1 text-slate-400 hover:text-rose-400 px-2 py-1 rounded transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            )}
          </div>
        </div>

        {/* Textarea */}
        <textarea
          rows={7}
          value={newsText}
          onChange={(e) => setNewsText(e.target.value)}
          placeholder="Paste or type any news article text here..."
          className="w-full bg-[#0b1120] text-slate-100 placeholder-slate-500 text-sm leading-relaxed rounded-lg p-3 border border-slate-800 focus:border-indigo-500 focus:outline-none resize-y min-h-[160px] font-sans"
        />

        {/* Footer controls */}
        <div className="mt-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center space-x-4">
            <span>Words: <strong className="text-slate-200">{wordCount}</strong></span>
            <span>Characters: <strong className="text-slate-200">{charCount}</strong></span>
          </div>

          <button
            type="button"
            onClick={onAnalyze}
            disabled={isAnalyzing || !newsText.trim()}
            className={`inline-flex items-center justify-center space-x-2 px-6 py-2.5 rounded-lg font-semibold text-white shadow transition-all ${
              isAnalyzing || !newsText.trim()
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-indigo-600/30'
            }`}
          >
            <Sparkles className={`w-4 h-4 ${isAnalyzing ? 'animate-spin' : ''}`} />
            <span>{isAnalyzing ? 'Running Pattern Analysis...' : 'Analyze News'}</span>
          </button>
        </div>

      </div>
    </div>
  );
}
