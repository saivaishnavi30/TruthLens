import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import NewsInputForm from './components/NewsInputForm';
import ResultDashboard from './components/ResultDashboard';
import HowItWorks from './components/HowItWorks';
import Footer from './components/Footer';
import { analyzeText } from './engine/detector';

const SAMPLE_ARTICLE = `SHOCKING SECRET REVEALED: Unverified Miracle Cure Cures Everything Overnight!

Guaranteed medical miracle! Scientists don't want you to know about this mind-blowing breakthrough that doctors are trying to ban. 

According to unconfirmed sources on social media, drinking this secret formula instantly reverses aging and eliminates all diseases without any scientific proof. You won't believe what happens next!

Act now before this secret information is taken down forever!`;

export default function App() {
  const [newsText, setNewsText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [hasAnalyzed, setHasAnalyzed] = useState(false);
  const [analysisResults, setAnalysisResults] = useState(null);

  const handleAnalyze = () => {
    if (!newsText.trim()) return;

    setIsAnalyzing(true);
    
    setTimeout(() => {
      // Execute REAL Aho-Corasick detection engine on user text input
      const realResults = analyzeText(newsText);

      setAnalysisResults(realResults);
      setHasAnalyzed(true);
      setIsAnalyzing(false);
    }, 400);
  };

  const handleLoadSample = () => {
    setNewsText(SAMPLE_ARTICLE);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#090d16] text-slate-100 font-sans">
      {/* 1. Header */}
      <Header />

      <main className="flex-1">
        {/* Short Description */}
        <Hero />

        {/* News Textarea & Analyze Button */}
        <NewsInputForm
          newsText={newsText}
          setNewsText={setNewsText}
          onAnalyze={handleAnalyze}
          isAnalyzing={isAnalyzing}
          onLoadSample={handleLoadSample}
        />

        {/* Real Suspicion Score, Verdict, Category Counts & Detected Phrases */}
        <ResultDashboard
          results={analysisResults}
          hasAnalyzed={hasAnalyzed}
        />

        {/* How It Works Pipeline (Trie -> Aho-Corasick -> Score) */}
        <HowItWorks />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
